// Enhanced stock price updates with visual indicators
class StockUpdater {
    constructor() {
        this.previousPrices = new Map();
        this.updateInterval = 5000; // 5 seconds
        this.init();
    }

    init() {
        this.updateStockTable();
        setInterval(() => this.updateStockTable(), this.updateInterval);
    }

    async updateStockTable() {
        try {
            const response = await fetch('/api/stocks');
            const stocks = await response.json();
            
            this.renderStockTable(stocks);
            this.updatePriceHistory(stocks);
        } catch (error) {
            console.error('Error updating stock prices:', error);
        }
    }

    renderStockTable(stocks) {
        const tableBody = document.querySelector('#stock-table tbody');
        if (!tableBody) return;

        tableBody.innerHTML = '';
        
        stocks.forEach(stock => {
            const row = this.createStockRow(stock);
            tableBody.appendChild(row);
        });
    }

    createStockRow(stock) {
        const row = document.createElement('tr');
        const previousPrice = this.previousPrices.get(stock.symbol) || stock.price;
        const priceChange = stock.price - previousPrice;
        
        // Determine price direction
        let priceClass = 'price-neutral';
        let arrowIcon = '';
        let changeClass = 'neutral';
        
        if (priceChange > 0) {
            priceClass = 'price-up';
            arrowIcon = '<i class="fas fa-arrow-up arrow arrow-up"></i>';
            changeClass = 'positive';
        } else if (priceChange < 0) {
            priceClass = 'price-down';
            arrowIcon = '<i class="fas fa-arrow-down arrow arrow-down"></i>';
            changeClass = 'negative';
        }

        // Format price change
        const changeText = priceChange !== 0 ? 
            `${arrowIcon} ₹${Math.abs(priceChange).toFixed(2)} (${Math.abs(stock.change_percent || 0).toFixed(2)}%)` : 
            '<i class="fas fa-minus arrow"></i> No change';

        row.className = priceClass;
        row.innerHTML = `
            <td>
                <strong>${stock.symbol}</strong>
                ${stock.last_updated ? `<br><small class="last-updated">Updated: ${this.formatTime(stock.last_updated)}</small>` : ''}
            </td>
            <td>${stock.name}</td>
            <td class="text-end">
                <div class="d-flex align-items-center justify-content-end gap-2">
                    <span class="fs-5 fw-bold">₹${stock.price.toFixed(2)}</span>
                </div>
                <div class="price-change ${changeClass}">
                    ${changeText}
                </div>
            </td>
        `;

        // Store current price for next comparison
        this.previousPrices.set(stock.symbol, stock.price);
        
        return row;
    }

    updatePriceHistory(stocks) {
        // Update any price history displays if they exist
        const historyElements = document.querySelectorAll('[data-stock-symbol]');
        historyElements.forEach(element => {
            const symbol = element.dataset.stockSymbol;
            const stock = stocks.find(s => s.symbol === symbol);
            if (stock) {
                this.updateHistoryElement(element, stock);
            }
        });
    }

    updateHistoryElement(element, stock) {
        // Update individual stock history displays
        const priceElement = element.querySelector('.current-price');
        const changeElement = element.querySelector('.price-change');
        
        if (priceElement) {
            priceElement.textContent = `₹${stock.price.toFixed(2)}`;
        }
        
        if (changeElement && stock.price_change !== 0) {
            const isPositive = stock.price_change > 0;
            changeElement.className = `price-change ${isPositive ? 'positive' : 'negative'}`;
            changeElement.innerHTML = `
                <i class="fas fa-arrow-${isPositive ? 'up' : 'down'} arrow arrow-${isPositive ? 'up' : 'down'}"></i>
                ₹${Math.abs(stock.price_change).toFixed(2)} (${Math.abs(stock.change_percent || 0).toFixed(2)}%)
            `;
        }
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false 
        });
    }
}

// Portfolio value updater
class PortfolioUpdater {
    constructor() {
        this.init();
    }

    init() {
        this.updatePortfolioValues();
        setInterval(() => this.updatePortfolioValues(), 10000); // Update every 10 seconds
    }

    async updatePortfolioValues() {
        try {
            const response = await fetch('/api/stocks');
            const stocks = await response.json();
            
            this.updateHoldingValues(stocks);
            this.updateTotalValue(stocks);
        } catch (error) {
            console.error('Error updating portfolio values:', error);
        }
    }

    updateHoldingValues(stocks) {
        const holdingElements = document.querySelectorAll('.holding-value');
        holdingElements.forEach(element => {
            const symbol = element.dataset.symbol;
            const quantity = parseInt(element.dataset.quantity);
            const stock = stocks.find(s => s.symbol === symbol);
            
            if (stock) {
                const value = quantity * stock.price;
                element.textContent = `₹${value.toFixed(2)}`;
                
                // Add visual indicator for value changes
                const previousValue = parseFloat(element.dataset.previousValue || value);
                if (value > previousValue) {
                    element.classList.add('text-success');
                    element.classList.remove('text-danger');
                } else if (value < previousValue) {
                    element.classList.add('text-danger');
                    element.classList.remove('text-success');
                }
                
                element.dataset.previousValue = value;
            }
        });
    }

    updateTotalValue(stocks) {
        const totalValueElement = document.querySelector('.total-portfolio-value');
        if (totalValueElement) {
            const cash = parseFloat(totalValueElement.dataset.cash || 0);
            let portfolioValue = 0;
            
            const holdings = document.querySelectorAll('.holding-value');
            holdings.forEach(element => {
                const symbol = element.dataset.symbol;
                const quantity = parseInt(element.dataset.quantity);
                const stock = stocks.find(s => s.symbol === symbol);
                
                if (stock) {
                    portfolioValue += quantity * stock.price;
                }
            });
            
            const totalValue = cash + portfolioValue;
            totalValueElement.textContent = `₹${totalValue.toFixed(2)}`;
        }
    }
}

// Announcement auto-refresh
class AnnouncementUpdater {
    constructor() {
        this.lastAnnouncementId = 0;
        this.init();
    }

    init() {
        this.checkForNewAnnouncements();
        setInterval(() => this.checkForNewAnnouncements(), 30000); // Check every 30 seconds
    }

    async checkForNewAnnouncements() {
        try {
            const response = await fetch('/api/announcements');
            const announcements = await response.json();
            
            if (announcements.length > 0) {
                const latestId = announcements[0].id;
                if (latestId > this.lastAnnouncementId) {
                    this.updateAnnouncementDisplay(announcements);
                    this.lastAnnouncementId = latestId;
                    
                    // Show notification for new announcement
                    this.showNewAnnouncementNotification(announcements[0]);
                }
            }
        } catch (error) {
            console.error('Error checking for announcements:', error);
        }
    }

    updateAnnouncementDisplay(announcements) {
        const container = document.querySelector('.announcements-container');
        if (!container) return;

        container.innerHTML = '';
        announcements.slice(0, 5).forEach(announcement => {
            const div = document.createElement('div');
            div.className = 'announcement';
            div.innerHTML = `
                <p class="announcement-text">${announcement.text}</p>
                <small class="announcement-time">${this.formatTime(announcement.timestamp)}</small>
            `;
            container.appendChild(div);
        });
    }

    showNewAnnouncementNotification(announcement) {
        // Create a toast notification for new announcements
        const toast = document.createElement('div');
        toast.className = 'toast position-fixed top-0 end-0 m-3';
        toast.style.zIndex = '1055';
        toast.innerHTML = `
            <div class="toast-header">
                <i class="fas fa-bullhorn text-primary me-2"></i>
                <strong class="me-auto">New Announcement</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${announcement.text}
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Initialize and show toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remove toast after it's hidden
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString('en-US', { 
            month: 'short',
            day: 'numeric',
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false 
        });
    }
}

// Initialize updaters when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new StockUpdater();
    new PortfolioUpdater();
    new AnnouncementUpdater();
    
    // Add loading indicators to forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                const originalText = submitBtn.textContent;
                submitBtn.innerHTML = '<span class="loading-spinner me-2"></span>Processing...';
                submitBtn.disabled = true;
                
                // Reset button after 5 seconds (fallback)
                setTimeout(() => {
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }, 5000);
            }
        });
    });
});

// Utility functions for enhanced user experience
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = '1056';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Enhanced form validation
function validateTradeForm(form) {
    const qty = parseInt(form.querySelector('[name="qty"]').value);
    const price = parseFloat(form.querySelector('[name="price"]').value);
    
    if (qty <= 0) {
        showAlert('Quantity must be greater than 0', 'danger');
        return false;
    }
    
    if (price <= 0) {
        showAlert('Price must be greater than 0', 'danger');
        return false;
    }
    
    return true;
}

// Add form validation to trade forms
document.addEventListener('DOMContentLoaded', () => {
    const tradeForms = document.querySelectorAll('form[data-trade-form]');
    tradeForms.forEach(form => {
        form.addEventListener('submit', (e) => {
            if (!validateTradeForm(form)) {
                e.preventDefault();
            }
        });
    });
});
